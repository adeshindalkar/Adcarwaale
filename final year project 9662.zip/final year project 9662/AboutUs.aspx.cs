﻿using System;

namespace final_year_project_9662
{
    public partial class AboutUs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Page Load logic (if needed)
        }
    }
}
