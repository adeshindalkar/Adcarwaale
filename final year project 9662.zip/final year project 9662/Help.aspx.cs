﻿using System;

namespace final_year_project_9662
{
    public partial class Help : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Logic to display dynamic content on the Help page if needed
        }
    }
}
